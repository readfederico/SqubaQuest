﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 250.0f;
    private Rigidbody2D _body;
    private Animator _anim;
    private BoxCollider2D _box;

    void Start()
    {
        _body = GetComponent<Rigidbody2D>();
        _anim = GetComponent<Animator>();
        _box = GetComponent<BoxCollider2D>();

    }

    private void Update()
    {
        Vector3 max = _box.bounds.max;
        Vector3 min = _box.bounds.min;

        Vector2 corner1 = new Vector2(min.x, max.y);
        Vector2 corner2 = new Vector2(min.x, min.y);
        Collider2D hit = Physics2D.OverlapArea(corner1, corner2);
     if (hit)
        {
            //Player Take damage
            //Delete Enemy
        }   
    }
}
